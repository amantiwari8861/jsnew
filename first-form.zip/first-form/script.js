const username=document.getElementById("username");
const password=document.getElementById("password");
const email=document.getElementById("email");
const number=document.getElementById("number");
const submit=document.getElementById("submit");
const form=document.getElementById("form");
const error=document.getElementById("error");
const errorMessage=document.getElementById("error-message");



username.addEventListener("keyup",function(){
    if(username.value.length>15){
        error.classList.remove("hidden");
        errorMessage.innerHTML="username must be less than 15 letters";
        error.style.left="2%";
        error.style.top="25%";
        username.classList.add("input-error");

    }
});

